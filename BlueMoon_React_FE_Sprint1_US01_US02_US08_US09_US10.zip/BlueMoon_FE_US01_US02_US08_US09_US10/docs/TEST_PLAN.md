# Checklist kiểm thử thủ công theo Acceptance Criteria

Điều kiện: backend chạy đúng contract v3, có tài khoản test BQT, ACCOUNTANT, RESIDENT, AUTHORITY và bộ dữ liệu mẫu. Dùng devtools Network kiểm tra HTTP method, URL, request body và status.

| US/AC | Test frontend | Kết quả mong đợi |
|---|---|---|
| US-08 AC1 | Đăng nhập tài khoản BQT, kế toán, cư dân | Điều hướng đúng route; sidebar đúng vai trò |
| US-08 AC2 | Nhập sai username/password | `INVALID_CREDENTIALS`, hiển thị thông báo tiếng Việt, không lưu token |
| US-08 AC3 | Sai liên tiếp 5 lần | `ACCOUNT_LOCKED`, đếm ngược `remainingSeconds`, disable login |
| US-08 phiên | Xóa/hết hạn JWT rồi mở trang riêng | 401 TOKEN_EXPIRED/TOKEN_INVALID đưa về login |
| US-01 AC1 | BQT tạo hộ đầy đủ và chủ hộ | POST hộ 201 → chi tiết hộ; counts = 1/1 |
| US-01 AC2 | Tạo trùng `householdCode` hoặc `apartmentNo` | `DUPLICATE`, hiển thị đúng lỗi dưới field |
| US-01 AC3 | Xóa hộ đã có giao dịch | `HAS_TRANSACTIONS`, hiện số giao dịch và nút chuyển ngừng hoạt động |
| US-01 AC4 | Thêm/sửa/xóa hộ | Bản ghi thay đổi; audit log phải được backend ghi (không có API đọc Sprint 1) |
| US-01 mở hộ | Xem hộ có chủ hộ/null | Hiển thị đúng, có nút đổi chủ hộ nếu có ứng viên RESIDING |
| US-01 quyền | Kế toán mở danh sách & chi tiết | Chỉ đọc; không có nút thêm/sửa/đổi/xóa |
| US-02 AC1 | Thêm thành viên vào hộ ACTIVE | POST `/households/{id}/residents` → xuất hiện trong danh sách hộ |
| US-02 AC2 | Xem hộ nhiều thành viên | Mảng thành viên, chủ hộ đứng đầu do backend sắp xếp |
| US-02 AC3 | Để trống họ tên/ngày sinh/quan hệ | Không gửi API, có lỗi field; nếu BE trả 400 cũng hiển thị |
| US-02 AC4 | Thêm thành viên vào hộ INACTIVE | Nút bị disable; nếu gọi API ngoài FE, backend trả HOUSEHOLD_INACTIVE |
| US-02 AC5 | Thêm/xóa nhân khẩu | Danh sách, residentCount/presentCount cập nhật sau reload API |
| US-02 xóa | Xóa nhân khẩu có lịch sử / gắn account / là chủ hộ | Giữ nguyên bản ghi, hiển thị `HAS_HISTORY` / `HAS_ACCOUNT` / `INVALID_NEW_HEAD` |
| US-02 cư trú | Bộ lọc `statusExpired=true`; `status=ALL` | Hiện quá hạn, đã chuyển đi/đã mất theo response, không tự chỉnh trạng thái |
| US-09 AC1 | Tạo user từng role | POST `/users`, roles đúng; khi role RESIDENT bắt chọn residentId |
| US-09 AC2 | Tạo trùng username/email | `DUPLICATE`, tô lỗi trường tương ứng |
| US-09 AC3 | Đăng nhập ACCOUNTANT/RESIDENT, truy cập thẳng URL `/tai-khoan` | FE chặn, BE vẫn phải 403 khi gọi API trái quyền |
| US-09 AC4 | Cấp tài khoản | Không trả passwordHash; audit log do backend ghi |
| US-09 khóa | Khóa user, thử token cũ | PATCH status 200; token cũ bị backend 401 TOKEN_INVALID |
| US-09 tự khóa | BQT thao tác khóa/chỉnh quyền bản thân | Không cho tự khóa, backend bắt buộc SELF_LOCKOUT |
| US-10 AC1 | Sửa tên/email/phone của chính mình | PUT `/me` 200, cập nhật header và profile |
| US-10 AC2 | Đổi mật khẩu hợp lệ | PATCH `/me/password` 204, logout, đăng nhập lại mật khẩu mới |
| US-10 AC3 | Mật khẩu cũ không đúng | 400/errors.oldPassword, giữ phiên đăng nhập |
| US-10 AC4 | Sửa profile tài khoản khác | Không có endpoint với id trong UI, backend chỉ thao tác `/me` |
| US-10 AC5 | Đổi mật khẩu, đăng nhập bằng mật khẩu cũ | Backend từ chối, không lưu JWT |
| Tích hợp | Tắt Spring Boot, thử GET | Thông báo không kết nối, không render dữ liệu giả |
| Responsive | Desktop 1440px, tablet 768px, mobile 375px | Sidebar chuyển drawer; bảng cuộn ngang, modal không tràn |

### Trước khi merge

- `npm run check` (kiểm tra source và quy ước route/endpoints)
- `npm run build` (sau `npm install` trong môi trường có mạng)
- Kiểm tra tất cả thao tác trên **backend thực tế**; chưa thể nói là đã pass E2E khi chỉ có file contract và SQL.
