# Các vấn đề cần backend/nhóm xác nhận trước khi merge

Nguồn: `API_Contract_sprint1_gd1.md`, `db_v1_giaidoan1.sql`, `SE_07-W02-UserStory (1).xlsx` (và NFR nhóm).

## Bắt buộc kiểm tra

| Mức độ | Điểm khác biệt | Hệ quả | Đề nghị |
|---|---|---|---|
| Chặn migration | File SQL dùng `//` sau một số dòng `CREATE EXTENSION`, `CREATE TABLE household`, `audit_log`. | PostgreSQL không hiểu `//` như comment. | Backend dùng `--` hoặc block comment hợp lệ. FE **không** chỉnh SQL. |
| Trái API | API có `gender=OTHER`, CHECK constraint `resident.gender` chỉ cho `MALE`, `FEMALE`. | Tạo/sửa nhân khẩu `OTHER` có thể lỗi DB. | Backend cập nhật migration hoặc xác nhận bỏ `OTHER` khỏi contract. UI đang hiển thị tùy chọn kèm chú thích cần backend hỗ trợ. |
| Trái API | API US-03 hỗ trợ `movementType=RETURN`, DB enum `resident_movement.movement_type` chưa cho `RETURN`. | Không ghi được RETURN khi tích hợp US-03. | Backend cập nhật DB trước khi tích hợp module US-03. |
| Cần xác nhận | Contract giới thiệu schema `V1__init_schema.sql` áp dụng US-01..04, 08..10; header SQL ghi Sprint 1 chỉ US-01..04, 08. | Dễ nhầm phiên bản migration. | Backend xác nhận đây là bản schema đang chạy, kiểm tra toàn bộ endpoint `/users`, `/me`. |
| Cần xác nhận | NFR nhóm có phiên bản nhắc Java desktop/MySQL/PostgreSQL; yêu cầu mới là ReactJS + Spring Boot + PostgreSQL. | Ràng buộc stack không thống nhất giữa các tài liệu. | Chốt stack mới theo API Contract v3 + yêu cầu hiện tại. |
| Phụ thuộc repo | Chưa có repo FE hiện tại, thiết kế hệ thống hoặc logo chính thức. | Không thể bảo đảm merge không conflict và style match. | Cung cấp repo/branch và design tokens trước khi merge. |
| Phụ thuộc API thật | Chỉ có tài liệu API, chưa có backend đang chạy/test account. | Chưa thể xác nhận response thật, CORS, trạng thái HTTP, seed data hoặc quyền. | Cho URL BE + tài khoản test BQT/ACCOUNTANT (đừng gửi mật khẩu thật, dùng tài khoản test). |

## Không tự thêm chức năng ngoài contract

- Không thêm dashboard số liệu, tìm kiếm tổng hợp `/search` (US-04), lịch sử biến động (US-03), phân trang cho `/households/{id}/residents` vốn là mảng.
- Không có endpoint gắn tài khoản cư dân đã tạo với residentId, không hiển thị thao tác đó. Nếu cần bổ sung, backend phải thống nhất contract mới.
- Không gọi `/auth/logout` vì optional; frontend hủy JWT tại client, backend không có refresh/revoke theo contract này.
- FE không tự ghi audit log: backend chịu trách nhiệm và Sprint 1 chưa có GET audit log.
- `statusUntil` và `statusExpired` hiển thị theo API, không tự tính / sửa DB.
