# Wireframe & luồng giao diện — BlueMoon Sprint 1

## Quy chuẩn UI

- Giao diện quản trị **tiếng Việt**, ưu tiên desktop nhưng co giãn trên tablet/mobile; sidebar trái, topbar người dùng, nội dung dạng panel/bảng.
- Bảng dùng API thực và phân trang **bắt đầu từ 1**, `size=20`; trường dữ liệu có dấu tiếng Việt Unicode.
- Màu trung tính sáng, xanh teal dùng cho hành động chính; trạng thái đỏ chỉ cho lỗi/xóa; không dùng màu làm tín hiệu duy nhất.
- Các form dùng modal: nút Lưu ngoài form phải vẫn gửi form; có validation client + server, loading, toast/trạng thái không có dữ liệu.
- Button bị ẩn hoặc disabled khi không có quyền/không đúng trạng thái, backend vẫn bắt buộc trả 403 khi gọi sai quyền.

## WF-00 — Khung ứng dụng

```text
┌────────────────────────┬──────────────────────────────────────────────────────────┐
│ BlueMoon               │ Hệ thống quản lý cư dân             [Họ tên · Vai trò] │
│ QUẢN LÝ CHUNG CƯ       ├──────────────────────────────────────────────────────────┤
│                        │ US-xx · TÊN CHỨC NĂNG                                   │
│  Trang chủ             │ Tiêu đề / giải thích              [Hành động chính]    │
│  Hộ gia đình           │ ┌────────────────────────────────────────────────────┐   │
│  Nhân khẩu             │ │ Thanh tìm kiếm + bộ lọc                           │   │
│  Tài khoản & phân quyền│ │ Bảng dữ liệu theo API                             │   │
│  Hồ sơ cá nhân         │ │ Phân trang 1-based                                │   │
│                        │ └────────────────────────────────────────────────────┘   │
│  Đăng xuất             │                                                          │
└────────────────────────┴──────────────────────────────────────────────────────────┘
```

Menu theo vai trò:
- **BQT:** Trang chủ, Hộ gia đình, Nhân khẩu, Tài khoản & phân quyền, Hồ sơ cá nhân, Đăng xuất.
- **Kế toán:** Trang chủ, Hộ gia đình (đọc), Nhân khẩu (đọc), Hồ sơ cá nhân, Đăng xuất.
- **Cư dân / Cơ quan chức năng:** Trang chủ, Hồ sơ cá nhân, Đăng xuất. Những module chưa có API không hiển thị.

## WF-08 — Đăng nhập

```text
┌─────────────────────────────┬────────────────────────────────┐
│ BLUE MOON                   │ [Biểu tượng bảo mật]           │
│ Quản lý cư dân rõ ràng hơn.  │ ĐĂNG NHẬP                      │
│                             │ Tên đăng nhập [____________]   │
│                             │ Mật khẩu     [___________👁]   │
│                             │ [       Đăng nhập        ]    │
│                             │ Sai thông tin / khóa tạm 15ph │
└─────────────────────────────┴────────────────────────────────┘
```

```mermaid
flowchart TD
  A[Trang đăng nhập] --> B[POST /auth/login]
  B -->|200 accessToken + user.roles| C[Lưu token phiên]
  C --> D{Vai trò?}
  D -->|BQT / ACCOUNTANT| E[Hộ gia đình]
  D -->|RESIDENT / AUTHORITY| F[Hồ sơ cá nhân]
  B -->|401 INVALID_CREDENTIALS| G[Hiện lỗi đăng nhập]
  B -->|423 ACCOUNT_LOCKED| H[Hiện khóa + đếm ngược]
  E --> I[GET /me xác thực phiên]
  F --> I
  I -->|401 TOKEN_EXPIRED / TOKEN_INVALID| A
```

## WF-01 — Hộ gia đình

```text
HỘ GIA ĐÌNH                                             [+ Thêm hộ gia đình]
┌──────────────────────────────────────────────────────────────────────────┐
│ [Tìm mã hộ / số căn hộ________]  [Trạng thái: Tất cả ▼]                 │
├─────────┬─────────┬────────────┬───────────┬──────────────┬─────────────┤
│ Mã hộ   │ Căn hộ  │ Chủ hộ     │ Diện tích │ Đang thuộc hộ│ Thực tế ở   │
├─────────┼─────────┼────────────┼───────────┼──────────────┼─────────────┤
│ H001    │ A101    │ Nguyễn...  │ 75.5 m²   │ 4            │ 3           │
└─────────┴─────────┴────────────┴───────────┴──────────────┴─────────────┘
                                        Trang 1/2   [<] [>]
```

Click hộ:

```text
CHI TIẾT CĂN HỘ A101                      [Chỉnh sửa] [+ Thêm nhân khẩu]
┌────────────────────┐ ┌──────────────────────────────────────┐
│ Mã hộ, căn hộ, tầng│ │ Chủ hộ + số người thuộc hộ + hiện ở│
│ Diện tích, trạng thái│ │ [Đổi chủ hộ]                       │
└────────────────────┘ └──────────────────────────────────────┘
┌─────────────────────────────────────────────────────────────┐
│ Thành viên thuộc hộ     [ ] Hiển thị cả người đã chuyển đi │
│ Bảng thành viên → click xem chi tiết nhân khẩu             │
└─────────────────────────────────────────────────────────────┘
[Ngừng hoạt động / Kích hoạt]  [Xóa hộ]
```

```mermaid
flowchart TD
  A[Danh sách hộ] --> B[GET /households]
  A -->|Thêm hộ BQT| C[Modal thông tin hộ + chủ hộ]
  C --> D[POST /households]
  D -->|201| E[Chi tiết hộ]
  D -->|400/409| C
  A -->|Click hộ| E
  E -->|Sửa| F[PUT /households/id]
  E -->|Đổi chủ hộ| G[PUT /households/id/head]
  E -->|Ngừng hoạt động| H[PATCH /households/id/status]
  E -->|Xóa| I[DELETE /households/id]
  I -->|204| A
  I -->|409 HAS_TRANSACTIONS| J[Giải thích + đề xuất ngừng hoạt động]
  J --> H
```

## WF-02 — Nhân khẩu

```text
NHÂN KHẨU
[Tìm họ tên_____________] [Trạng thái ▼] [ ] Chỉ quá hạn
┌────────────┬──────────┬───────────┬─────────────┬──────────────┐
│ Họ và tên  │ Ngày sinh│ Hộ / Căn  │ Quan hệ     │ Cư trú       │
├────────────┼──────────┼───────────┼─────────────┼──────────────┤
│ Nguyễn...  │ 01/01/...│ H001 A101 │ Con         │ Đang cư trú  │
└────────────┴──────────┴───────────┴─────────────┴──────────────┘
```

- Thêm nhân khẩu chỉ trong **chi tiết hộ**: nhập họ tên, ngày sinh, quan hệ, CCCD/điện thoại, `entryType` (`MOVE_IN`, `BIRTH`, `TEMPORARY_RESIDENCE`, `EXISTING`), ngày phù hợp. `TEMPORARY_RESIDENCE` mới hiện `startDate`, `endDate`.
- Chi tiết nhân khẩu: thông tin cá nhân và cư trú; BQT được sửa thông tin và xóa nhập nhầm; kế toán chỉ xem. Không sửa `isHead`, `householdId`, `residencyStatus` bằng `PUT /residents/{id}`.
- Luồng xóa nhân khẩu bị chặn: `HAS_HISTORY` → hướng xử lý biến động US-03; `HAS_ACCOUNT` → xử lý liên kết tài khoản; `INVALID_NEW_HEAD` → đổi chủ hộ trước. Không ép xóa.

## WF-09 — Tài khoản và phân quyền

```text
TÀI KHOẢN & PHÂN QUYỀN                                [+ Cấp tài khoản]
[Tìm username / họ tên____] [Vai trò ▼] [Trạng thái ▼]
┌──────────┬───────────────┬────────────────┬──────────────┬────────────────┐
│ Username │ Họ tên        │ Vai trò        │ Hoạt động    │ Thao tác       │
├──────────┼───────────────┼────────────────┼──────────────┼────────────────┤
│ kt01     │ Trần...       │ Kế toán        │ Hoạt động    │ Quyền | Khóa   │
└──────────┴───────────────┴────────────────┴──────────────┴────────────────┘

MODAL CẤP TÀI KHOẢN
Tên đăng nhập, mật khẩu ban đầu, họ tên, email, điện thoại
[ ] Ban quản trị  [ ] Kế toán  [ ] Cư dân  [ ] Cơ quan chức năng
Nếu có Cư dân: [Tìm nhân khẩu RESIDING ______] → chọn residentId
[Hủy] [Tạo tài khoản]
```

- Gán quyền từ `GET /roles`, không hardcode tên role trong dropdown từ dữ liệu bên ngoài.
- `SELF_LOCKOUT` hiển thị khi cố khóa bản thân hoặc tự loại bỏ BQT; frontend cũng chặn nút tự khóa.
- Chưa có API sửa email/tên của tài khoản khác trong contract: không tự xây nút giả.

## WF-10 — Hồ sơ cá nhân

```text
HỒ SƠ CÁ NHÂN
[Avatar]  Họ tên — username — vai trò
┌─────────────────────┐ ┌─────────────────────────────────────────┐
│ Thông tin tài khoản │ │ [Thông tin cá nhân] [Đổi mật khẩu]      │
│ Username            │ │ Tên đầy đủ: [____________________]     │
│ Vai trò             │ │ Email:       [____________________]    │
│ Lần đăng nhập       │ │ Điện thoại:  [____________________]    │
│ Ngày tạo            │ │ [Lưu thay đổi]                         │
└─────────────────────┘ └─────────────────────────────────────────┘
```

Đổi mật khẩu: `oldPassword`, `newPassword`, `confirmPassword` → validate → `PATCH /me/password` → **204 → xóa token → login lại**. Không gọi API trên tài khoản khác.
