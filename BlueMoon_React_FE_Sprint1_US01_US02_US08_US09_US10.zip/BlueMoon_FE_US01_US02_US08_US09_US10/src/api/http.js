const BASE_URL = (import.meta.env.VITE_API_BASE_URL || '/api/v1').replace(/\/$/, '');
export class ApiError extends Error {
  constructor(payload = {}, status = 0) {
    super(payload.message || (status === 0 ? 'Không thể kết nối máy chủ. Kiểm tra Spring Boot hoặc kết nối mạng.' : 'Đã xảy ra lỗi. Vui lòng thử lại.'));
    this.name = 'ApiError';
    this.code = payload.code || 'NETWORK_ERROR';
    this.status = status;
    this.fields = payload.errors || {};
    this.details = payload.details || {};
  }
}
export async function request(method, path, { body, params, signal, skipAuth = false } = {}) {
  const url = new URL(BASE_URL + path, window.location.origin);
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && String(value) !== '') url.searchParams.set(key, String(value));
  });
  const token = sessionStorage.getItem('bluemoon_access_token');
  const headers = { Accept: 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token && !skipAuth) headers.Authorization = `Bearer ${token}`;
  let response;
  try {
    response = await fetch(url.toString(), { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal });
  } catch (err) {
    if (err?.name === 'AbortError') throw err;
    throw new ApiError({}, 0);
  }
  if (response.status === 204) return null;
  let payload;
  try { payload = await response.json(); } catch { throw new ApiError({ message: 'Phản hồi máy chủ không phải JSON hợp lệ.' }, response.status); }
  if (!response.ok || payload?.success === false) {
    if (response.status === 401 && !skipAuth && ['TOKEN_EXPIRED', 'TOKEN_INVALID', 'UNAUTHORIZED'].includes(payload?.code)) {
      window.dispatchEvent(new CustomEvent('bluemoon:session-expired', { detail: payload?.message }));
    }
    throw new ApiError(payload, response.status);
  }
  if (!Object.prototype.hasOwnProperty.call(payload || {}, 'data')) {
    throw new ApiError({ message: 'Phản hồi thiếu trường data theo API Contract.' }, response.status);
  }
  return payload.data;
}
export const api = {
  get: (path, params, opts) => request('GET', path, { params, ...opts }),
  post: (path, body, opts) => request('POST', path, { body, ...opts }),
  put: (path, body, opts) => request('PUT', path, { body, ...opts }),
  patch: (path, body, opts) => request('PATCH', path, { body, ...opts }),
  delete: (path, opts) => request('DELETE', path, opts),
};
