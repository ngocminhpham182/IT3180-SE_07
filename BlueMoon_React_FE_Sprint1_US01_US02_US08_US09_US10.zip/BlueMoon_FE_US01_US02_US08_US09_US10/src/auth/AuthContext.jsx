import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { authApi } from '../api/services';
const AuthContext = createContext(null);
const TOKEN = 'bluemoon_access_token';
const STORED_USER = 'bluemoon_user';
export const homeForRoles = (roles = []) => roles.some(r => r === 'BQT' || r === 'ACCOUNTANT') ? '/ho-gia-dinh' : '/ho-so';
export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => sessionStorage.getItem(TOKEN));
  const [user, setUser] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem(STORED_USER) || 'null'); } catch { return null; }
  });
  const [loading, setLoading] = useState(() => Boolean(sessionStorage.getItem(TOKEN)));
  const [notice, setNotice] = useState('');
  const signOut = useCallback((message = '') => {
    sessionStorage.removeItem(TOKEN); sessionStorage.removeItem(STORED_USER);
    setToken(null); setUser(null); setLoading(false); setNotice(message);
  }, []);
  const updateUser = useCallback((value) => { setUser(value); sessionStorage.setItem(STORED_USER, JSON.stringify(value)); }, []);
  const login = useCallback(async (credentials) => {
    const result = await authApi.login(credentials);
    if (!result?.accessToken || !result?.user) throw new Error('Đăng nhập thành công nhưng máy chủ thiếu accessToken hoặc user.');
    sessionStorage.setItem(TOKEN, result.accessToken);
    setToken(result.accessToken); updateUser(result.user); setNotice('');
    return result.user;
  }, [updateUser]);
  useEffect(() => {
    if (!token) { setLoading(false); return; }
    let mounted = true;
    authApi.me().then(data => { if (mounted) { updateUser(data); setLoading(false); } })
      .catch(err => { if (mounted) {
        if (['TOKEN_EXPIRED','TOKEN_INVALID','UNAUTHORIZED'].includes(err.code) || err.status === 401) signOut('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
        else signOut('Không thể xác minh phiên đăng nhập với máy chủ. Vui lòng kết nối và đăng nhập lại.');
      }});
    return () => { mounted = false; };
  }, [token, signOut, updateUser]);
  useEffect(() => {
    const handler = (event) => signOut(event.detail || 'Phiên đăng nhập không còn hợp lệ. Vui lòng đăng nhập lại.');
    window.addEventListener('bluemoon:session-expired', handler);
    return () => window.removeEventListener('bluemoon:session-expired', handler);
  }, [signOut]);
  return <AuthContext.Provider value={{ token, user, loading, notice, setNotice, login, signOut, updateUser, hasRole: (r) => (user?.roles || []).includes(r) }}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
